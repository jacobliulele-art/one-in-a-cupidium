---
name: add-answers
description: Add, move or remove answers for a One in a Cupidium prompt, or fix an answer's rarity tier or aliases. Use when asked to add answers, make an answer count, change how rare an answer is, or block a wrong answer.
---

# Adding or fixing answers

All hand edits go in a dated fix block at the **end of the answer bank**, so they run after every
generated bank and the automatic re-tiering. Don't edit the generated banks in `data/answers.js`
for one-off fixes — later passes re-tier and dedupe them, so the result is hard to predict.

## 1. Find the prompt's exact name

```bash
grep -n '"Name a cocktail"' index.html data/*.js
```

The name must match exactly (capitals and punctuation). A misspelled name is silently ignored —
`tools/check.js` catches this.

## 2. Pick the tier

| Tier | Meaning |
|------|---------|
| 0 | most common answers (about 15) |
| 1 | common (about 40) |
| 2 | middle |
| 3 | everything else valid |
| 4 | ONE IN A CUPIDIUM: 1–5 fun deep cuts |

Aliases: write `main name/other name/abbrev` as one entry, e.g. `united kingdom/uk`.
Lowercase everything.

## 3. Write the edit

Find the newest fix block (`grep -n "answer fixes" index.html`). For today's changes, add a new block
right after it (before the `</script>` that ends the first script), dated like the others:

```js
// ===== <Month Day> answer fixes: <one-line reason> =====
{const P=q=>PROMPTS.find(p=>p.q===q);
 const put=(q,tier,list)=>{const p=P(q);if(!p)return;p.t=p.t||[];while(p.t.length<5)p.t.push("");
   for(const a of list.split("|")){const ns=new Set(a.split("/").map(y=>y.trim().toLowerCase()));p.t=p.t.map(s=>s.split("|").filter(x=>x&&!x.split("/").some(y=>ns.has(y.trim().toLowerCase()))).join("|"));
     p.t[tier]=p.t[tier]?p.t[tier]+"|"+a:a;}};
 put("Name a cocktail",3,"white lady|corpse reviver");
}
```

`put()` adds the answer if it's missing, or moves it to the new tier if it's already there
(matching on any alias). If a fix block for today already exists, add `put(...)` lines to it.

Other fixes, inside the same block:
- **Remove an answer:**
  `{const p=P("Name a disease caused by bacteria");if(p)p.t=p.t.map(s=>s.split("|").filter(x=>x&&x.split("/")[0].trim().toLowerCase()!=="scurvy").join("|"));}`
- **Tier-4 fun pick** (highlighted deep cut): also set `FUN_PICKS["<prompt>"]="+answer|+answer"`,
  guarded with `if(typeof FUN_PICKS==="object")`; optional one-line reason in `BLURBS`.
- **Block an answer the AI judge wrongly accepts:**
  `window.AI_REJECT=Object.assign(window.AI_REJECT||{},{"<prompt>":["wrong answer"]});`

## 4. Check

```bash
node tools/check.js
```

It must print `OK`. Then, if a browser tool is available, load the game, open ALL ANSWERS for that
prompt, and confirm the answer shows in the right tier.

## Notes

- Players can also add answers to the shared bank on the relay (`/bank`); those live on the server,
  not in this repo. This skill is for answers baked into the game.
- New prompts are different: copy the style of the nearest "More prompts" / "Krillion-style prompts"
  section instead.
