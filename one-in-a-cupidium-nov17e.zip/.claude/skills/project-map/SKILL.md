---
name: project-map
description: Map of the One in a Cupidium game repo — where the code, answer data, art and maps live and how to find a section. Use before reading or editing index.html or data/*.js.
---

# One in a Cupidium — project map

A browser trivia game (rarer valid answers score more) plus an arcade, casino and party modes.
Plain HTML + JavaScript, no framework, no build step needed to play. The live relay server is a
separate repo (`lele-io/cupidium-relay`, a Cloudflare Worker).

## Files

| Path | What it is |
|------|------------|
| `index.html` | All game code: CSS at the top, then two big `<script>` blocks. ~1.6 MB. |
| `data/prompts.js` | The starting prompt list (`OIC_DATA.PROMPTS`) and two added lists (`PROMPT_LIST_1`, `PROMPT_LIST_2`) |
| `data/answers.js` | Answer banks: `EXTRA`, `BIG`, `MORE_ANSWERS`, `MORE`, `ADDB_1..24`, `RARE_KEEP`, `FUN_PICKS`, `BLURBS`, `FOODW` |
| `data/words.js` | Daily Cuepon word lists: `CW_OK`, `CW_BEE` (the short `CW_ANS` list stays in index.html) |
| `data/decks.js` | `DECK_BASE` (casino/arcade decks) |
| `data/art.js` | Pixel art: `BBART_1`, `BBART_2`, `TR_ART`, `EPX` |
| `data/maps.js` | `TR_MAPDATA` (arcade level maps) |
| `tools/check.js` | Safety check — run after every edit: `node tools/check.js` |

The `data/*.js` files are loaded by `<script src>` tags just before the first inline script and put
everything on `window.OIC_DATA`. The game code reads them as `OIC_DATA.<name>` at the spot where the
data used to be written inline, so load order and behaviour are unchanged.

## Finding things

- Never read `index.html` or `data/answers.js` whole — they are huge. Grep, then read a range.
- Sections are marked with comment headers. List them with:
  `grep -n "^// =====\|^// =================" index.html`
- Main sections (script 1 = answer bank, script 2 = the game):
  - Answer bank: `PROMPTS` array, then "New prompts", "Big answer banks", "Big fill-in pass" (ADDB),
    "Krillion-shape tiers", "re-tier every other prompt", then the dated answer-fix blocks (latest: "Nov 16 answer fixes")
  - Game: Config, Helpers, Sound, Scene engine, Screen management, Learned answers, Smart matching,
    Wikipedia, AI judge, Menu, Daily/practice, Endless, Rapid Fire, Party, Online rooms, CUPIDIUM RUSH,
    CUPIDIUM ARCADE, CUPIDIUM CASINO, DAILY CUEPON, Friends, Leaderboards, Puffer Party, Boot,
    shared answer bank (relay)
- To find one prompt's answers: `grep -n '"Name a fruit"' index.html data/*.js`

## Answer format

- A prompt has `t:[tier0, tier1, tier2, tier3, tier4]`, each a `|`-separated string.
- Tiers: 0 = most common (about 15), 1 = common (about 40), 2 = middle, 3 = everything else valid,
  4 = ONE IN A CUPIDIUM (1–5 fun deep cuts).
- `a/b/c` inside one entry = one answer with aliases (first name is the main one).
- To add or move answers, use the add-answers skill.

## Relay (other repo)

`cupidium-relay/index.js`: ntfy-style pub/sub topics (`/<topic>`, `/<topic>/sse`), the shared answer
bank (`/bank`), WebSocket party rooms (`/ws/<room>`), and duels (`/duel`). One Durable Object class,
`Topic`. Deploy with `npx wrangler deploy`.

## After editing

1. `node tools/check.js` (must print OK)
2. Open `index.html` through a local server (`npx serve .` or `python3 -m http.server`).
3. Friends play from the GitHub link, so `data/` must be uploaded along with `index.html`.
